#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void char2int_(char *char_ptr, int *intval) {

     *intval = atoi(char_ptr);
}

